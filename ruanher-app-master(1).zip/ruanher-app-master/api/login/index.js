import {
	api
} from '../../util/requests.js'
 
//用户登录接口 这是一个接口  api的参数分别是 请求路径（不包括基础路径 ，基础路径在请求里面封装好了） 第二个是请求方法（默认GET） 第三个参数是携带的参数
//暴露出一个login 函数 在页面调用即可 
export const login = (params) => api('api/Login', 'GET', params);
//用户信息
export const getUserInfo = (params) => api('api/getUserInfo','GET', params);

