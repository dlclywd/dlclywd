<template>
	<view style="padding: 28rpx;">
		<view >
			<u-input prefixIcon="account-fill" placeholder="请输入旧密码..." color="#2469f6" border="none" v-model="oldpwd"
				clearable
				customStyle="height:90rpx;background:#eaf2fe;border-radius:25rpx;padding-left:15rpx;padding-right:15rpx;"
				placeholderStyle="color:#949494" prefixIconStyle="color:#2469f6" fontSize="18"></u-input>
		</view>
		<view style="margin-top: 28rpx;">
			<u-input prefixIcon="account-fill" placeholder="请输入新密码..." color="#2469f6" border="none" v-model="newpwd"
				clearable
				customStyle="height:90rpx;background:#eaf2fe;border-radius:25rpx;padding-left:15rpx;padding-right:15rpx;"
				placeholderStyle="color:#949494" prefixIconStyle="color:#2469f6" fontSize="18"></u-input>
		</view>
		<view style="margin-top: 28rpx;">
			<u-input prefixIcon="account-fill" placeholder="请重复输入新密码..." color="#2469f6" border="none" v-model="newpwd1"
				clearable
				customStyle="height:90rpx;background:#eaf2fe;border-radius:25rpx;padding-left:15rpx;padding-right:15rpx;"
				placeholderStyle="color:#949494" prefixIconStyle="color:#2469f6" fontSize="18"></u-input>
		</view>
		<view style="margin-top: 28rpx;">
		 	  <u-button size="large" text="立即修改" color="#2469f6" iconColor="#fff"
		        customStyle="height:90rpx;border-radius:25rpx;" @click="changeword()">
		    </u-button>
		</view>
		<u-toast ref="uToast"></u-toast>
	</view>
</template>
<script>
	import API from '../../util/request.js';
	export default {
		data() {
			return {
				oldpwd: '',
				newpwd: '',
				newpwd1: ''
			}
		},
		methods: {
			changeword(){
				let Token = uni.getStorageSync('Token');
				let user = uni.getStorageSync('User');
				if(this.newpwd===this.newpwd1){
					uni.request({
					    url: API.UpdatePassword() + user + '&usertoken=' + Token + '&oldpwd=' + this.oldpwd +
					        '&newpwd=' + this.newpwd ,
					    success: (res) => {
					        var data = JSON.parse(this.AES.decrypt(res.data, API.JmKey(), API
					        .JmIv()));
					        console.log(data)
					        if(data.code==200){
					            this.$refs.uToast.show({
					            	type: 'success',
					            	message: data.msf,
                                    complete() {
                                        uni.setStorageSync('SET_ISLOGIN', false);
										uni.removeStorageSync('User');
                                        uni.removeStorageSync('Token');
                                        uni.navigateTo({
                                        	url:'/pages/account/login'
                                        })
                                    }
					            })
								
					        }else{
					            this.$refs.uToast.show({
					            	type: 'error',
					            	message: data.msf,
					            })
					        }
					    }
					})
				}else{
					this.$refs.uToast.show({
						type: 'error',
						message: '新密码两次输入不一致',
					})
				}
			},
		}
	}
</script>
<style>
</style>
