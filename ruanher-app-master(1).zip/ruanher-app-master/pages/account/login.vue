<template>
	<view>
		<image style="width: 100%;" src="../../static/common/lgbg.png" mode="widthFix"></image>
		<view class="head">
			<view style="padding: 50rpx;">
				<u-text text="登录" size="30" color="#2469f6" bold></u-text>
				<view style="margin-top: 60rpx;">
					<u-input prefixIcon="account" placeholder="请输入账号..." color="#2469f6" border="none"
						v-model="loginForm.username" clearable
						customStyle="height:90rpx;background:#eaf2fe;border-radius:25rpx;padding-left:15rpx;padding-right:15rpx;"
						placeholderStyle="color:#949494" prefixIconStyle="color:#2469f6" fontSize="18"></u-input>
				</view>
				<view style="margin-top: 60rpx;">
					<u-input prefixIcon="lock" placeholder="请输入密码..." color="#2469f6" border="none"
						v-model="loginForm.password" password clearable placeholderStyle="color:#949494"
						customStyle="height:90rpx;background:#eaf2fe;border-radius:25rpx;padding-left:15rpx;padding-right:15rpx;"
						prefixIconStyle="color:#2469f6" fontSize="18"></u-input>
				</view>
				<u-row justify="space-between" customStyle="margin-top: 15rpx">
					<u-col span="3">
						<u-text text="忘记密码?" color="#2469f6" decoration="underline" @click="Toforget()"></u-text>
					</u-col>
					<u-col span="3" offset="6.9">
						<u-text text="立即注册" color="#2469f6" decoration="underline" @click="Toregister()"></u-text>
					</u-col>
				</u-row>
				<view style="margin-top: 60rpx;">
					<u-button size="large" text="立即登录" color="#2469f6" iconColor="#fff"
						customStyle="height:90rpx;border-radius:25rpx;" @click="Login()">
					</u-button>
				</view>
				<view style="margin-top: 50rpx;">
					<u-checkbox-group>
						<u-checkbox v-model="isyes" name="login" :disabled="false" @change="checkboxChange">
						</u-checkbox> 我已阅读同意<view style="color: blue;" @click="Goxy">《服务协议》</view>和<view style="color: blue;" @click="Goys">《隐私政策》</view>
					</u-checkbox-group>
				</view>
			</view>
		</view>
		<u-toast ref="uToast" position="bottom"></u-toast>
	</view>
</template>
<script>
	import {
		login
	} from '../../api/login/index.js';
	import user from '../../store/modules/user';
	import API from '../../util/request.js';
	export default {
		data() {
			return {
				cur: 0,
				loginForm: {
					username: '', //账号
					password: ''
				},
				isyes: false
			}
		},
		onLoad() {},
		methods: {
			checkboxChange(e) {
				this.isyes = e;
			},
			Goys() {
				uni.navigateTo({
					url: `/pages/commen/webview?url=https://tool.freeapks.cn/tk/yszc.html`
				})
			},
			Goxy() {
				uni.navigateTo({
					url: `/pages/commen/webview?url=https://tool.freeapks.cn/tk/fwxy.html`
				})
			},
			QQlogin() {
				uni.getProvider({
					service: 'oauth', // 授权登录
					success: function(resp) {
						console.log(resp.provider); // 服务商
						if (~resp.provider.indexOf(resp.provider)) {
							uni.login({
								provider: resp.provider,
								success: function(infoResp) {
									// 用户信息
									console.log(infoResp);
								}
							});
						}
					}
				});
			},
			Login: function() {
				if (this.isyes == false) {
					this.$refs.uToast.show({
						type: 'error',
						message: '请阅读并勾选同意协议条款!',
					})
				} else {
					uni.showLoading({
						title: "正在登陆..."
					})
					user.actions.Login(this.cur, this.loginForm).then(res => {
						var data = JSON.parse(this.AES.decrypt(res, API.JmKey(), API.JmIv()));
						console.log(data)
						if (data.code === 200) {
							uni.setStorageSync('SET_ISLOGIN', true);
							uni.setStorageSync('Token', data.data.usertoken);
							uni.setStorageSync('User', data.data.username);
							uni.hideLoading()
							this.$refs.uToast.show({
								type: 'success',
								message: data.msf,
								complete() {
									uni.switchTab({
										url: '../my/my'
									})
								}
							})
						} else if (data.code == 400) {
							uni.hideLoading()
							if (data.msf == "username不能为空") {
								this.$refs.uToast.show({
									type: 'error',
									message: '请输入账号!',
								})
							} else if (data.msf == "username不能为空") {
								this.$refs.uToast.show({
									type: 'error',
									message: '请输入密码!',
								})
							} else {
								this.$refs.uToast.show({
									type: 'error',
									message: data.msf,
								})
							}
						}
					})
				}
			},
			Toregister: function() {
				uni.navigateTo({
					url: '/pages/account/register'
				})
			},
			Toforget: function() {
				uni.navigateTo({
					url: '/pages/account/forget'
				})
			}
		}
	}
</script>
<style>
	page {
		background-color: #fff;
	}

	.head {
		/* padding: 50rpx; */
		width: 100%;
		background-color: #fff;
		position: absolute;
		border-radius: 60rpx 60rpx 0 0;
		margin-top: -110rpx;
	}

	.qqbody {
		margin-top: 60rpx;
		display: flex;
		justify-content: center;
	}

	.qqbox {
		background-color: #00d49c;
		width: 80rpx;
		height: 80rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		border-radius: 50%;
	}
</style>