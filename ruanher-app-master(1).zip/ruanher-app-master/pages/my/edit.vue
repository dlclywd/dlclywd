<template>
    <view style="padding: 30rpx;">
        <view>
            <u-input prefixIcon="account-fill" placeholder="请输入昵称..." color="#2469f6" border="none" v-model="nickname"
                clearable
                customStyle="height:90rpx;background:#eaf2fe;border-radius:25rpx;padding-left:15rpx;padding-right:15rpx;"
                placeholderStyle="color:#949494" prefixIconStyle="color:#2469f6" fontSize="18"></u-input>
        </view>
        <view style="margin-top: 60rpx;">
            <u-input prefixIcon="integral-fill" placeholder="请输入个性签名..." color="#2469f6" border="none"
                v-model="signature" clearable
                customStyle="height:90rpx;background:#eaf2fe;border-radius:25rpx;padding-left:15rpx;padding-right:15rpx;"
                placeholderStyle="color:#949494" prefixIconStyle="color:#2469f6" fontSize="18"></u-input>
        </view>
        <view style="margin-top: 60rpx;">
            <u-input prefixIcon="email-fill" placeholder="请输入邮箱..." color="#2469f6" border="none" v-model="useremail"
                clearable
                customStyle="height:90rpx;background:#eaf2fe;border-radius:25rpx;padding-left:15rpx;padding-right:15rpx;"
                placeholderStyle="color:#949494" prefixIconStyle="color:#2469f6" fontSize="18"></u-input>
        </view>
        <view style="margin-top: 60rpx;">
         	  <u-button size="large" text="立即修改" color="#2469f6" iconColor="#fff"
                customStyle="height:90rpx;border-radius:25rpx;" @click="Edit()">
            </u-button>
        </view>
        <u-toast ref="uToast"></u-toast>
    </view>
</template>

<script>
    import API from '../../util/request.js';
    export default {
        data() {
            return {
                nickname: '',
                signature: '',
                useremail: ''
            }
        },
        methods: {
            Edit: function() {
                let Token = uni.getStorageSync('Token');
                let user = uni.getStorageSync('User');
                
                uni.request({
                    url: API.updateuserInfo() + user + '&usertoken=' + Token + '&nickname=' + this.nickname +
                        '&signature=' + this.signature+ '&useremail=' + this.useremail,
                    success: (res) => {
						console.log(res)
                        var data = JSON.parse(this.AES.decrypt(res.data, API.JmKey(), API
                        .JmIv()));
                        console.log(data)                        
                        if(data.code==200){                            
                            this.$refs.uToast.show({
                            	type: 'success',
                            	message: data.msf,
                                complete() {
                                    uni.switchTab({
                                    	url:'../my/my'
                                    })
                                }
                            });
                            
                        }else{
                            this.$refs.uToast.show({
                            	type: 'error',
                            	message: data.msf,
                            })
                        }
                        
                    }
                })
                
            }
        }
    }
</script>

<style>
</style>
