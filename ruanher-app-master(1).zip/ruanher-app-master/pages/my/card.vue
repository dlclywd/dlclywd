<template>
    <view style="padding: 20rpx;">
        <u-alert :title="title" type="primary " effect="dark"></u-alert>
        <view style="margin-top: 30rpx;">
            <u-input prefixIcon="car" placeholder="请输入卡密..." color="#2469f6" border="none" v-model="card" clearable
                customStyle="height:90rpx;background:#eaf2fe;border-radius:25rpx;padding-left:15rpx;padding-right:15rpx;"
                placeholderStyle="color:#949494" prefixIconStyle="color:#2469f6" fontSize="18"></u-input>
        </view>
        <view style="margin-top: 30rpx;">
            <u-button size="large" text="立即兑换" color="#2469f6" iconColor="#fff"
                customStyle="height:90rpx;border-radius:25rpx;" @click="UseKm()">
            </u-button>
        </view>
        <u-toast ref="uToast"></u-toast>
    </view>
</template>

<script>
    import API from '../../util/request.js';
    export default {
        data() {
            return {
                card: '',
                title: '在此输入你获取的卡密，然后进行兑换所相应的产品，可以兑换会员，金币等等！！'
            }
        },
        methods: {
            UseKm: function() {
                let user = uni.getStorageSync('User');
                let token = uni.getStorageSync('Token');
                uni.request({
                    url: API.UserKm() + user + '&km=' + this.card,
                    success: (res) => {
						var data = JSON.parse(this.AES.decrypt(res.data, API.JmKey(), API
						.JmIv()));
                        console.log(data)
                        if (data.code == 200) {
                            this.$refs.uToast.show({
                                type: 'success',
                                message: data.msf,
                                complete() {
                                    uni.switchTab({
                                    	url:'../my/my'
                                    })
                                }
                            })
                        } else {
                            this.$refs.uToast.show({
                                type: 'error',
                                message: data.msf,
                            })
                        }
                    }
                })
            }
        }
    }
</script>

<style>
</style>
