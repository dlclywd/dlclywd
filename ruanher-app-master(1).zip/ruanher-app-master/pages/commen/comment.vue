<template>
	<view>
		<u-navbar placeholder title="发表评论/评分" leftIcon="arrow-left" bgColor="#ffffff" leftIconSize="25" autoBack
			right-icon="edit-pen" @rightClick="Sendcom(appid,star,content)">
		</u-navbar>
		<view class="apphead">
			<view class="appbox">
				<view class="imgbox">
					<u-image :src="appicon" width="80" height="80" radius="20"></u-image>
				</view>
			</view>
			<u-text :text="appname" align="center"></u-text>
			<view class="appbox" style="margin-top: 15px;">
				<u-rate :value="star" size="30" allowHalf inactiveIcon="star-fill" activeColor="#2469f6"
					@change="changestar"></u-rate>
			</view>
			<u-text :text="'当前评分：'+star" align="center" size="13" color="#888888" style="margin-top: 5px;"></u-text>
			<view style="margin: 10px;">
				<u-line></u-line>
				<u-textarea v-model="content" border="none" placeholder="请输入评论/评分内容" autoHeight count
					style="margin-top: 10px;"></u-textarea>
			</view>
		</view>
		<u-toast ref="uToast"></u-toast>
	</view>
</template>
<script>
	import API from '../../util/request.js';
	export default {
		data() {
			return {
				appid: '',
				appname: '',
				appicon: '',
				star: 0,
				content: ''
			}
		},
		onLoad(e) {
			var that = this;
			that.appid = e.appid;
			that.appname = e.appname;
			that.appicon = e.appicon;
			// console.log(this.appid)
		},
		methods: {
			changestar(e) {
				console.log(e)
				this.star = e;
			},
			Sendcom(appid, star, content) {
				let token = uni.getStorageSync('Token');
				let user = uni.getStorageSync('User');
				if (this.star == 0) {
					var star = 6;
				} else {
					var star = this.star;
				}
				if (token !== null && token !== '') {
					uni.request({
						url: API.comment() + user + '&usertoken=' + token + '&parentid=0&star=' + star +
							'&content=' + this.content + '&appid=' + this.appid,
						success: (res) => {
							var data = JSON.parse(this.AES.decrypt(res.data, API.JmKey(), API.JmIv()));
							// console.log(data)
							if (data.code == 200) {
								this.$refs.uToast.show({
									type: 'success',
									message: data.msf,
									complete() {
										uni.navigateBack({
											delta: 1, // 返回的页面数，如果delta为1，则返回上一页，如果delta为2，则返回上两页，以此类推
											success: function() {
												console.log('返回上一页成功')
											}
										})
									}
								})
							} else {
								this.$refs.uToast.show({
									type: 'error',
									message: data.msf
								})
							}
						}
					})
				} else {
					uni.navigateTo({
						url: '/pages/account/login'
					})
				}
			}
		}
	}
</script>
<style>
	page {
		background-color: #fff;
	}

	.apphead {
		margin-top: 30px;
	}

	.appbox {
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.imgbox {
		width: 80px;
		height: 80px;
		border-radius: 20px;
		border: #dcdcdc 1px solid;
		margin-bottom: 10px;
	}
</style>