<template>
	<view>
		<u-navbar placeholder leftIcon="arrow-left" bgColor="#ffffff" leftIconSize="25" autoBack>
			<view slot="center">
				<u-text text="软件发布" bold></u-text>
			</view>
			<view slot="right">
				<u-icon name="edit-pen" size="28" @click="addapk()"></u-icon>
			</view>
		</u-navbar>
		<view class="pages">
			<u-alert title="请勿投稿严重侵权产品,软件名称,简介,链接等不得包括任何形式的引流行为,必须保证软件长期可用性,否则将不会审核通过,情节严重的,将永久封存账号." type="error">
			</u-alert>
			<lsj-upload style="margin-top: 28rpx;" ref="lsjUpload" childId="upload1" :count="1" formats="apk" :option="option" :multiple="false"
				:instantly="instantly" @uploadEnd="onuploadEnd" @progress="onprogre" @change="change">
				<u-button  text="上传软件" color="#00aa7f"></u-button>
			</lsj-upload>
			<view >
				<view class="mt28">
					<text
					    style="color: #00aa7f;text-shadow: 2rpx 2rpx 5rpx rgba(0, 170, 127, 0.5);margin-left: 6rpx;font-weight: bold;">▍软件名称</text>
					<u-input :value="appname" v-model="appname" placeholder="请输入软件名称~" 
					customStyle="background: rgba(228, 243, 238, 1.0);padding:0 20rpx 0 20rpx;margin-top:8rpx;height:88rpx;border-radius:18rpx"
					color="#00aa7f" order="none" placeholderStyle="color:#00aa7f"  clearable></u-input>
				</view>
				<view class="mt28">
					<text
					    style="color: #00aa7f;text-shadow: 2rpx 2rpx 5rpx rgba(0, 170, 127, 0.5);margin-left: 6rpx;font-weight: bold;">▍软件包名</text>
					<u-input :value="apppage" v-model="apppage" placeholder="请输入软件包名~"
					customStyle="background: rgba(228, 243, 238, 1.0);padding:0 20rpx 0 20rpx;margin-top:8rpx;height:88rpx;border-radius:18rpx"
					color="#00aa7f" order="none" placeholderStyle="color:#00aa7f"  clearable></u-input>
				</view>
				<view class="mt28">
					<text
					    style="color: #00aa7f;text-shadow: 2rpx 2rpx 5rpx rgba(0, 170, 127, 0.5);margin-left: 6rpx;font-weight: bold;">▍软件版本</text>
					<u-input :value="appbb" v-model="appbb" placeholder="请输入软件版本~"
					customStyle="background: rgba(228, 243, 238, 1.0);padding:0 20rpx 0 20rpx;margin-top:8rpx;height:88rpx;border-radius:18rpx"
					color="#00aa7f" order="none" placeholderStyle="color:#00aa7f"  clearable></u-input>
				</view>
				<view class="mt28">
					<text
					    style="color: #00aa7f;text-shadow: 2rpx 2rpx 5rpx rgba(0, 170, 127, 0.5);margin-left: 6rpx;font-weight: bold;">▍软件图标</text>
					<u-input :value="appicon" v-model="appicon" placeholder="请输入软件图标链接地址~"
					customStyle="background: rgba(228, 243, 238, 1.0);padding:0 20rpx 0 20rpx;margin-top:8rpx;height:88rpx;border-radius:18rpx"
					color="#00aa7f" order="none" placeholderStyle="color:#00aa7f"  clearable>
					<template slot="suffix">
					    <u-button text="上传图片" color="#00aa7f" size="normal"  customStyle="height:66rpx" @click="Upicon()"></u-button>
					</template></u-input>
				</view>
				<view class="mt28">
					<text
					    style="color: #00aa7f;text-shadow: 2rpx 2rpx 5rpx rgba(0, 170, 127, 0.5);margin-left: 6rpx;font-weight: bold;">▍软件下载地址</text>
					<u-input :value="appdownurl" v-model="appdownurl" placeholder="请输入软件下载地址~"
					customStyle="background: rgba(228, 243, 238, 1.0);padding:0 20rpx 0 20rpx;margin-top:8rpx;height:88rpx;border-radius:18rpx"
					color="#00aa7f" order="none" placeholderStyle="color:#00aa7f"  clearable></u-input>
				</view>
				<view class="mt28">
					<text
					    style="color: #00aa7f;text-shadow: 2rpx 2rpx 5rpx rgba(0, 170, 127, 0.5);margin-left: 6rpx;font-weight: bold;">▍软件大小</text>
					<u-input :value="appsize" v-model="appsize" placeholder="请输入软件大小~"
					customStyle="background: rgba(228, 243, 238, 1.0);padding:0 20rpx 0 20rpx;margin-top:8rpx;height:88rpx;border-radius:18rpx"
					color="#00aa7f" order="none" placeholderStyle="color:#00aa7f"  clearable></u-input>
				</view>
				<view class="mt28">
					<text
					    style="color: #00aa7f;text-shadow: 2rpx 2rpx 5rpx rgba(0, 170, 127, 0.5);margin-left: 6rpx;font-weight: bold;">▍软件介绍</text>
					<u-textarea v-model="appmsg" color="#00aa7f" customStyle="background: rgba(228, 243, 238, 1.0);padding:20rpx;margin-top:8rpx;border-radius:18rpx" placeholder="请输入内容" placeholderStyle="color:#00aa7f"></u-textarea>
					<!-- <u-input :value="appmsg" v-model="appmsg" placeholder="请输入软件介绍~"
					customStyle="background: rgba(228, 243, 238, 1.0);padding:0 20rpx 0 20rpx;margin-top:8rpx;height:88rpx;border-radius:18rpx"
					color="#00aa7f" order="none" placeholderStyle="color:#00aa7f"  clearable></u-input> -->
				</view>
				<view class="mt28">
				    <text
				        style="color: #00aa7f;text-shadow: 2rpx 2rpx 5rpx rgba(0, 170, 127, 0.5);margin-left: 6rpx;font-weight: bold;">▍软件分类</text>
				    <u-cell icon="grid-fill" :border="false" :title="sortname" iconStyle="color:#00aa7f;" titleStyle="color:#00aa7f;"
				        customStyle="background: rgba(228, 243, 238, 1.0);margin-top:8rpx;height:88rpx;border-radius:18rpx"
				        @click="OpenClass">
				    </u-cell>
				    <!-- <u-picker :show="show" :columns="appclass" keyName=classname closeOnClickOverlay @change="change" @cancel="cancel" @confirm="confirm"></u-picker> -->
				    <u-picker :show="show" :columns="columns" keyName="sortname" closeOnClickOverlay @cancel="cancel"
				        :loading="loading" @confirm="confirm" @close="close" @change="change1" title="软件分类"></u-picker>
				</view>
				<view class="mt28">
				    <text
				        style="color: #00aa7f;text-shadow: 2rpx 2rpx 5rpx rgba(0, 170, 127, 0.5);margin-left: 6rpx;font-weight: bold;">▍是否MOD版</text>
				    <u-cell icon="gift-fill" :border="false" :title="modname" iconStyle="color:#00aa7f;" titleStyle="color:#00aa7f;"
				        customStyle="background: rgba(228, 243, 238, 1.0);margin-top:8rpx;height:88rpx;border-radius:18rpx"
				        @click="OpenClass1">
				    </u-cell>
				    <!-- <u-picker :show="show" :columns="appclass" keyName=classname closeOnClickOverlay @change="change" @cancel="cancel" @confirm="confirm"></u-picker> -->
				    <u-picker  :columns="ismod" keyName="modname" closeOnClickOverlay @cancel="cancel1"
				        :show="show1" @confirm="confirm1" @close="close1" @change="change2" title="是否MOD"></u-picker>
				</view>
				<view class="mt28">
					<text
					    style="color: #00aa7f;text-shadow: 2rpx 2rpx 5rpx rgba(0, 170, 127, 0.5);margin-left: 6rpx;font-weight: bold;">▍软件标签</text>
					<u-input :value="apptag" v-model="apptag" placeholder="请输入软件标签,使用英文;分割~"
					customStyle="background: rgba(228, 243, 238, 1.0);padding:0 20rpx 0 20rpx;margin-top:8rpx;height:88rpx;border-radius:18rpx"
					color="#00aa7f" order="none" placeholderStyle="color:#00aa7f"  clearable></u-input>
				</view>
				<view class="mt28">
					<text
					    style="color: #00aa7f;text-shadow: 2rpx 2rpx 5rpx rgba(0, 170, 127, 0.5);margin-left: 6rpx;font-weight: bold;">▍软件横幅图</text>
					<u-input :value="apphenfu" v-model="apphenfu" placeholder="请输入软件横幅图链接地址~"
					customStyle="background: rgba(228, 243, 238, 1.0);padding:0 20rpx 0 20rpx;margin-top:8rpx;height:88rpx;border-radius:18rpx"
					color="#00aa7f" order="none" placeholderStyle="color:#00aa7f"  clearable>
					<template slot="suffix">
					    <u-button text="上传图片" color="#00aa7f" size="normal"  customStyle="height:66rpx" @click="Uphenfu()"></u-button>
					</template></u-input>
				</view>
				<view class="mt28">
					<text
					    style="color: #00aa7f;text-shadow: 2rpx 2rpx 5rpx rgba(0, 170, 127, 0.5);margin-left: 6rpx;font-weight: bold;">▍软件截图</text>
					
					<u-upload
						:fileList="appscelist"
						@afterRead="afterRead"
						@delete="deletePic"
						name="file"
						multiple
						:maxCount="4"
						width="80"
						height="165" style="margin-top: 10px;">
					<image src="http://demo.ruanher.com/uploads/images/20230627/cdac1622ead4cca1e0dfa99519ae0df1.png" 
						mode="widthFix" style="width: 80px;height: 120px;"></image>
					</u-upload> 
				</view>
			</view>
		</view>
		<u-toast ref="uToast"></u-toast>
	</view>
</template>
<script>
	import API from '../../util/request.js';
	export default {
		data() {
			return {
				// 上传接口参数
				option: {
					// 上传服务器地址，需要替换为你的接口地址
					url: '', // 该地址非真实路径，需替换为你项目自己的接口地址
					// 上传附件的key
					name: 'file',
				},
				// 选择文件后是否立即自动上传，true=选择后立即上传
				instantly: true,
				// 文件回显列表
				files: new Map(),
				// 演示用
				tabIndex: 0,
				list: [],
				sortname: '选择软件分类',
				modname: '选择是否MOD',
				show: false,
				show1: false,
				loading: false,
				columns: [],
				sorts:[],
				ismod:[
					[
						{mod:0,modname:'否'},
						{mod:1,modname:'是'}
					],
				],
				apkmsg:'',
				appname:'',
				apppage:'',
				appbb:'',
				appicon:'',
				appdownurl:'',
				appsize:'',
				appsortid:'',
				appmod:'',
				apptag:'',
				apphenfu:'',
				appscelist:[],
				appmsg:''
			}
		},
		onLoad() {
			this.option.url = API.upapp();
		},
		methods: {
			addapk(){
				var appsce = '';
				for (let i = 0; i < this.appscelist.length; i++) {
					if(i<this.appscelist.length-1){
						appsce += this.appscelist[i].url+','
					}else{
						appsce += this.appscelist[i].url
					}
				}
				let token = uni.getStorageSync('Token');
				let user = uni.getStorageSync('User');
				uni.request({
					url: API.addapp() + user +'&usertoken='+token+'&appname='+this.appname+'&appicon='+this.appicon+'&appsortid='+this.appsortid+'&apppage='+this.apppage+'&appmsg='+this.appmsg+
					'&appmod='+this.appmod+'&appbb='+this.appbb+'&appdata='+this.appsize+'&apphenfu='+this.apphenfu+'&appsce='+appsce+'&appdownurl='+this.appdownurl+'&apptag='+this.apptag,
					success: (res) => {
						console.log(res)
						var datas = JSON.parse(this.AES.decrypt(res.data, API.JmKey(), API.JmIv()));
						console.log(datas)
						if (datas.code == 200) {
							this.$refs.uToast.show({
							    type: 'success',
							    message: '发布成功，等待管理员审核',
								complete() {
								    uni.navigateBack(1)
								}
							})
						}else{
							this.$refs.uToast.show({
								type: 'error',
								message: datas.msf
							})
						}
					},
				})
			},
			// 删除图片
			deletePic(e) {
				this.appscelist.splice(e.index, 1)
			},
			// 新增图片
			async afterRead(e) {
				// 当设置 mutiple 为 true 时, file 为数组格式，否则为对象格式
				let lists = [].concat(e.file)
				let appscelistLen = this.appscelist.length
				lists.map((item) => {
					this.appscelist.push({
						...item,
						status: 'uploading',
						message: '上传中'
					})
				})
				for (let i = 0; i < lists.length; i++) {
					const result = await this.uploadFilePromise(lists[i].url)
					let item = this.appscelist[appscelistLen]
					this.appscelist.splice(appscelistLen, 1, Object.assign(item, {
						status: 'success',
						message: '',
						url: result
					}))
					appscelistLen++
					
				}
				
			},
			uploadFilePromise(url) {
				return new Promise((resolve, reject) => {
					let a = uni.uploadFile({
						url: API.UploadImg(), // 仅为示例，非真实的接口地址
						filePath: url,
						name: 'file',
						success: (res) => {
							var datas = JSON.parse(this.AES.decrypt(res.data, API.JmKey(), API.JmIv()));
							console.log(datas)
							setTimeout(() => {
								resolve(datas.data.img)
							}, 1000)
						}
					});
				})
			},
			Upicon(){
				uni.chooseImage({
				    count: 1,
				    success: (chooseImageRes) => {
				        const tempFilePaths = chooseImageRes.tempFilePaths;
				        // console.log(tempFilePaths)
				        uni.showLoading({
				            title: '上传中...'
				        })
				        let user = uni.getStorageSync('User');
				        uni.uploadFile({
				        	url: API.UploadImg(), // 仅为示例，非真实的接口地址
				        	filePath: tempFilePaths[0],
				        	name: 'file',
				        	success: (res) => {
				        		var datas = JSON.parse(this.AES.decrypt(res.data, API.JmKey(), API.JmIv()));
				        		this.appicon=datas.data.img
								uni.hideLoading()
				        	}
				        });
				    }
				});
			},
			Uphenfu(){
				uni.chooseImage({
				    count: 1,
				    success: (chooseImageRes) => {
				        const tempFilePaths = chooseImageRes.tempFilePaths;
				        // console.log(tempFilePaths)
				        uni.showLoading({
				            title: '上传中...'
				        })
				        let user = uni.getStorageSync('User');
				        uni.uploadFile({
				        	url: API.UploadImg(), // 仅为示例，非真实的接口地址
				        	filePath: tempFilePaths[0],
				        	name: 'file',
				        	success: (res) => {
				        		var datas = JSON.parse(this.AES.decrypt(res.data, API.JmKey(), API.JmIv()));
				        		this.apphenfu=datas.data.img
								uni.hideLoading()
				        	}
				        });
				    }
				});
			},
			//选择分类
			OpenClass() {
			    var that = this;
			    that.show = true;
			    that.loading = true;
				uni.request({
					url: API.GetApkClass(),
					success: res => {
						var datas = JSON.parse(that.AES.decrypt(res.data, API.JmKey(), API.JmIv()));
						that.sorts[0] = datas.data
						uni.$u.sleep(1500).then(() => {
						    that.columns = that.sorts;
						    that.loading = false;
							console.log(that.columns)
						})  
									   
					}
				})
			},
			//滑动选择器
			change1(e) {
			    // console.log(e.value);
			},
			//关闭选择器
			close() {
			    // console.log('close');
			    this.show = false
			},
			//点击取消
			cancel() {
			    // console.log('cancel');
			    this.show = false
			},
			//选择器点击确定
			confirm(e) {
			    // console.log('confirm', e);
			    this.show = false
			    this.sortname = '已选择：' + e.value[0].sortname
			    this.appsortid = e.value[0].id
			},
			
			
			//选择MOD
			OpenClass1() {
			    var that = this;
			    that.show1 = true;
			},
			//点击取消
			cancel1() {
			    // console.log('cancel');
			    this.show1 = false
			},
			//滑动选择器
			change2(e) {
			    // console.log(e.value);
			},
			//关闭选择器
			close1() {
			    // console.log('close');
			    this.show1 = false
			},
			//选择器点击确定
			confirm1(e) {
			    // console.log('confirm', e);
			    this.show1 = false
			    this.modname = '已选择：' + e.value[0].modname
			    this.appmod = e.value[0].mod
			},
			
			/**
			 * 某文件上传结束回调(成功失败都回调)
			 * @param {Object} item 当前上传完成的文件 
			 */
			onuploadEnd(item) {
				var that = this;
				that.files.set(item.name, item);
				var code = JSON.parse(that.AES.decrypt(item.responseText, API.JmKey(),
						API.JmIv()));
				that.files.get(item.name).responseText = code;
				
				// 强制更新视图
				that.$forceUpdate();
				// ---可删除--演示判断是否所有文件均已上传成功
				let isAll = [...that.files.values()].find(item => item.type !== 'success');
				if (!isAll) {
					that.appname=code.data.appname;
					that.apppage=code.data.apppage;
					that.appbb=code.data.appbb;
					that.appicon=code.data.appicon;
					that.appdownurl=code.data.appdownurl;
					that.appsize=code.data.appsize;
					uni.hideLoading()
				} else {
					console.log(isAll.name + '待上传');
				}
			},
			/**
			 * 上传进度回调
			 * 如果网页上md文档没有渲染出事件名称onprogre，请复制代码的小伙伴自行添加上哈，没有哪个事件是只(item)的
			 * @param {Object} item 当前正在上传的文件
			 */
			onprogre(item) {
				// 更新当前状态变化的文件
				this.files.set(item.name, item);
				// console.log(this.files.set(item.name, item))
				// 强制更新视图
				this.$forceUpdate();
			},
			/**
			 * 文件选择回调
			 * @param {Object} files 已选择的所有文件Map集合
			 */
			change(files) {
				// 更新选择的文件 
				this.files = files;
				// 强制更新视图
				this.$forceUpdate();
				uni.showLoading({
					title:'上传中...'
				})
				// ---可删除--演示重新定位覆盖层控件				
			},
			// 手动上传
			upload() {
				// name=指定文件名，不指定则上传所有type等于waiting和fail的文件
				this.$refs['lsjUpload' + this.tabIndex].upload();
			},
			/**
			 * 指定上传某个文件
			 * @param {Object} name 带后缀名的文件名称
			 */
			resetUpload(name) {
				this.$refs['lsjUpload' + this.tabIndex].upload(name);
			},
			/**
			 * 移除某个文件
			 * @param {Object} name 带后缀名的文件名称
			 */
			clear(name) {
				// name=指定文件名，不传name默认移除所有文件
				this.$refs['lsjUpload' + this.tabIndex].clear(name);
			},
			add() {
				this.list.push('DOM重排测试');
			},
		}
	}
</script>
<style lang="less">
	.pages{
		padding: 10px;
	}
	.mt28 {
	    margin-top: 28rpx;
	}
</style>