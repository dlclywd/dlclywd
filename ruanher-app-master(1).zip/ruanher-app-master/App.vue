<script>
    import {
    	checkUpdate
    } from "./components/yzhua006-update/js/app-update-check.js";
    import API from './util/request.js';
	export default {
		onLaunch: function() {
            // var test = plus.navigator.getSignature();
            // var test1 = plus.navigator.isSimulator();
            // var test2 = plus.navigator.isRoot();
            // var test3 = plus.networkinfo.isSetProxy();
            // console.log(test)
            // console.log(API.AppKey())
            // console.log(test1)
            // if(test!==API.AppKey()||test3=="true"||test1=="true"){
            //     plus.runtime.quit();
            // }
            const system_info = uni.getSystemInfoSync();
            let params = {
            	os: system_info.platform //本机设备操作系统  （android || ios）
            }
            if (params.os != 'ios' && params.os != 'android') false; //如果不是安卓或ios 返回false
            uni.request({
            	url: API.GetAppUpdate(),
            	success: (res) => {
            		var data = JSON.parse(this.AES.decrypt(res.data, API.JmKey(), API.JmIv()));
            		let update_info = data.data
            		checkUpdate(update_info, 0).then(res => {
            			if (res.msg) {
            				plus.nativeUI.toast(res.msg);
            			}
            		}); 
                    uni.request({
                        url: API.addview(),
                        success: res => {
                        }
                    })
            	}
            });
		},
		onShow: function() {
			
		},
		onHide: function() {
			
		}
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	@import "@/uni_modules/uview-ui/index.scss";
	@import "common/demo.scss";    
	page{
		background-color: #f7f7f7; 
	}
 
</style>