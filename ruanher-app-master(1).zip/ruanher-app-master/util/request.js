var API = 'http://demo.ruanher.com/';
module.exports = {
	//应用信息
	GetAppInfo: function() {
		return API + 'api/getApp'
	},
	//获取所有分类
	GetApkClass:function(){
	    return API + 'api/listSection'
	},
	//获取软件列表
	GetApkList:function(){
	    return API + 'api/listApp'
	},
	
    //用户注册
    Register:function(){
    	return API + 'api/Register?username='
    },
	//获取注册验证码
	GetRegCode:function(){
    	return API + 'api/sendRegcode?useremail='
    },
	
    //解密KEY
    JmKey:function(){
        return '1212121212121212'
    }, 
    //解密KEY
    JmIv:function(){
        return '3434343434343434'
    },
	
	//获取最新版本
	GetAppUpdate:function(){
    	return API + 'api/getUpdate'
    },
	//获取用户信息
	GetUserInfo:function(){
		return API + 'api/getUserInfo?username='
	},
	//使用卡密
	UserKm:function(){
		return API + 'api/UserKm?username='
	},
	//签到
	UserSign:function(){
		return API + 'api/UserSign?username='
	},
	//获取订单列表
	Getshoporder:function(){
		return API + 'api/Getshoporder?usertoken='
	},
	//获取会员商品列表
	GetShopList:function(){
		return API + 'api/GetShopList'
	},
	//邀请码生成
	Getinvitecode:function(){
		return API + 'api/Getinvitecode?username='
	},
	//绑定邀请码
	Invitation:function(){
		return API + 'api/Invitation?username='
	},
	//邀请排行榜
	GetinviterList:function(){
		return API + 'api/GetinviterList'
	},
	//修改用户资料
	updateuserInfo:function(){
		return API + 'api/updateuserInfo?username='
	},
	//修改密码
	UpdatePassword:function(){
		return API + 'api/UpdatePassword?username='
	},
	//新增访问量
	addview:function(){
		return API + 'api/addview'
	},
	//获取软件详情
	getAppinfo:function(){
		return API + 'api/getAppinfo?id='
	},
	//获取用户/软件评论/评分
	listComment:function(){
		return API + 'api/listComment'
	},
	//下载软件
	downapp:function(){
		return API + 'api/downapp?id='
	},
	//获取热门/最新软件
	newhotApp:function(){
		return API + 'api/newhotApp?paixu='
	},
	//获取软件标签列表
	gettags:function(){
		return API + 'api/gettags'
	},
	//发表评分/评论
	comment:function(){
		return API + 'api/comment?username='
	},	
	//上传头像
	UploadHead:function(){
		return API + 'api/UploadHead?username='
	},
	//获取广告
	getads:function(){
		return API + 'api/getads?type='
	},
	//发起支付
	BuyShop:function(){
		return API + 'api/BuyShop?usertoken='
	},
	//上传软件
	upapp:function(){
		return API + 'api/upapp'
	},
	//发布软件
	addapp:function(){
		return API + 'api/addapp?appusername='
	},
	//上传图片
	UploadImg:function(){
		return API + 'api/UploadImg'
	},
    //证书KEY
    AppKey:function(){
        return 'a74d4812a16d822b218b0159e8cffda7164df1f5'
    },
    
}
