# 软盒后台管理系统

#### 介绍
软盒系统的前端APP


#### 更新说明
更新日期：2023.07.24
版本：1.0.8.23724
1. 修复分类页CSS问题
2. 修复软件标签的软件列表接口问题，并更换新接口
3. 修复热门/最新软件，一直加载第一页问题

更新日期：2023.07.21
版本：1.0.7.23721
1. 新增软件发布功能
2. 修复升级问题

更新日期：2023.07.12
版本：1.0.6.2312
1. 新增分享链接功能
2. 修复我的页面显示BUG
3. 优化我的页面判断逻辑

更新日期：2023.07.08
版本：1.0.5.2378.1
1. 新增支付功能


更新日期：2023.07.08
版本：1.0.5.2378
1. 新增广告功能

更新日期：2023.07.04
1. 修复上传头像问题
2. 新增列表处下载按钮点击事件
3. 修复其他BUG

更新日期：2023.07.01-1
1. 修复部分UI问题

更新日期：2023.07.01
1. 新版发布

#### 关于

1.  官方博客 [qcodes.cn](https://qcodes.cn)
2.  软盒官方网站 [ruanher.com](https://www.ruanher.com)，后台请前往官方网站下载
3.  开源交流群 [云程开源](http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=zB7sDF1eYaV6Q_S_9nWvP6fOFEWk8fsg&authKey=VndIirOcIoEqON9w9Mr8x%2F7wMPz%2FqGpkLE89ZvUpTbqJFk5WKgEYNUZgjHC2Nv1B&noverify=0&group_code=235492833)[软盒官方交流](http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=xRUyz-8gBcrFVKEOf_WEvuXiYNlFqBvB&authKey=AV0R3XfiIql%2Fo9toLVcrUfCQXB94h3og864jgBpdV3i6ij4J71xNVGLMXYRBe%2BM%2B&noverify=0&group_code=515095967)